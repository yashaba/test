export interface BasicData {
    message: string;
  }
  