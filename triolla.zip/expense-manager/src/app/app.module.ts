import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SideBarComponent } from './components/side-bar/side-bar.component';
import { LoginScreenComponent } from './login-screen/login-screen.component';
import { SignInComponent } from '../app/pages/sign-in/sign-in.component';
import { ConfigurationPageComponent } from './pages/configuration-page/configuration-page.component';
import { ExpenseTrackerPageComponent } from './pages/expense-tracker/expense-tracker-page.component';
import { ExpenseCreationModalComponent } from './components/expense-creation-modal/expense-creation-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    SideBarComponent,
    LoginScreenComponent,
    SignInComponent,
    ConfigurationPageComponent,
    ExpenseTrackerPageComponent,
    ExpenseCreationModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
