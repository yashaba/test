import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpenseTrackerPageComponent } from './expense-tracker-page.component';

describe('ExpenseTrackerPageComponent', () => {
  let component: ExpenseTrackerPageComponent;
  let fixture: ComponentFixture<ExpenseTrackerPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpenseTrackerPageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpenseTrackerPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
