import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expense-tracker-page',
  templateUrl: './expense-tracker-page.component.html',
  styleUrls: ['./expense-tracker-page.component.scss']
})
export class ExpenseTrackerPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
