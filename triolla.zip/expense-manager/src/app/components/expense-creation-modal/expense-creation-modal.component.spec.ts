import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpenseCreationModalComponent } from './expense-creation-modal.component';

describe('ExpenseCreationModalComponent', () => {
  let component: ExpenseCreationModalComponent;
  let fixture: ComponentFixture<ExpenseCreationModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpenseCreationModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpenseCreationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
