import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expense-creation-modal',
  templateUrl: './expense-creation-modal.component.html',
  styleUrls: ['./expense-creation-modal.component.scss']
})
export class ExpenseCreationModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
