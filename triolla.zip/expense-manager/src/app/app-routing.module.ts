import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignInComponent } from './pages/sign-in/sign-in.component';
import { ConfigurationPageComponent } from './pages/configuration-page/configuration-page.component';
import { ExpenseTrackerPageComponent } from './pages/expense-tracker/expense-tracker-page.component';

const routes: Routes = [
  {component:SignInComponent , path:''},
  {component:ConfigurationPageComponent , path:'configuration'},
  {component:ExpenseTrackerPageComponent , path:'expenses'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


  
 }
